import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int[] bills = {50, 100, 200, 500};
        int goal = 10000;
        int current = 0;
        int giftCount = 0;
        while (!(current >= goal)){
            int gift = bills[rnd.nextInt(bills.length)];
            current += gift;
            giftCount++;
            System.out.println("Подарок " + giftCount + " друг подарил " + gift + " долларов. Сейчас на счету " +current + " долларов");
        }
        System.out.println("Вы накопили нужную сумму");
        System.out.println("Давайте выпьем!");
    }
}
//Задание 1
//Напиши программу, которая моделирует ситуацию.
//Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
// Каждый друг случайным образом может подарить тебе одну купюру
// номиналом 50, 100, 200 или 500 долларов.
// Твоя цель - новенький игровой компьютер, который стоит 10 000 долларов.
//Как только друзья подарят тебе нужную сумму (или даже чуть больше),
// останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!