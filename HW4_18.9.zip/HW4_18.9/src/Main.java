import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        Random rnd = new Random();
        int currentFloor = rnd.nextInt(0, 36);
        System.out.println("Лифт находится на " + currentFloor + " этаже");
        int userFloor;
        do {
            System.out.println("Введите ваш текущий этаж");
            userFloor = scn.nextInt();
        } while ((userFloor < 0) || (userFloor > 35));
        //System.out.println("данного этажа не существует");
        //if ((userFloor < 0) || (userFloor > 35)){
        //};
        System.out.println("Лифт начинает движение");
        while (userFloor != currentFloor) {
            if (currentFloor < userFloor) {
                currentFloor++;
            } else {
                currentFloor--;
            }
            System.out.println(currentFloor);
        }
        System.out.println("Лифт прибыл на ваш этаж");
    }
}
//Напишите программу, моделирующую работу табло при ожидании лифта.
//В здании 35 этажей. Лифт находится на произвольном этаже в диапазоне от 0 до 35
// (выбирается случайно). Пользователь нажимает кнопку вызова лифта
// (вводит на каком этаже он находится). После этого лифт начинает движение.
// Пользователь может видеть, как лифт движется по этажам
// (программа должна выводить каждый этаж лифта, когда лифт движется).