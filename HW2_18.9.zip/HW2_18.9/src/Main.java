import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        do {
            int summ = 0;
            for (int i = 1; i < 10; i++) {
                if (i % 2 != 0){
                    summ += i;
                }
            }
            System.out.println("сумма всех нечетных чисел в заданном диапазоне равна " + summ);
            System.out.println("Введите 'quit' чтобы завершить программу");
        } while (!scn.nextLine().equalsIgnoreCase("quit"));
        System.out.println("Программа завершена.");

    }
}
//Задание 2
//Используйте for для вычисления суммы.
//Используйте do-while для организации повторения программы.
//Необходимо суммировать все нечётные целые числа в диапазоне,
// введённом пользователем. Программу повторять, пока пользователь не введёт «quit».