import daysOfWeek.DaysOfWeek;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите текущий день недели");
        DaysOfWeek current = DaysOfWeek.valueOf(scn.nextLine().toUpperCase());
        System.out.println("Дни недели кроме " + current + ":");
        for (DaysOfWeek day: DaysOfWeek.values()) {
            if (day != current){
                System.out.println(day);
            }
        }
    }
}
//Задание 3
//Используйте foreach.
//Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
// Программа должна вывести все дни недели, кроме данного.